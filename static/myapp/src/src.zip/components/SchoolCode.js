import React, {Component} from 'react';

class SchoolCode extends Component {
    static defaultProps = {
        info: {
            name: '이름'
        },
    }
    state = {
        name: "",
        data: ""
    }

    constructor(props) {
        super(props);
        console.log("SDF")
    }

    componentDidMount() {
        console.log("rendered")
    }

    componentDidUpdate(prevProps, prevState) {
        console.log(this.props.data)
        this.setState({data : "aaaa", name : "aasdfsd"}
        )
    }

    render() {
        const {name} = this.props.data;

        return (
            <div>
                검색 한 거 <br/>
                {name}

            </div>
        );
    }


}

export default SchoolCode;


