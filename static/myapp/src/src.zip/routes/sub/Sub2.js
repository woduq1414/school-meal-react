import React from 'react'

const Sub2 = () => {
    return (
        <div>
			POST SUB2
        </div>
    )
}

export default Sub2
