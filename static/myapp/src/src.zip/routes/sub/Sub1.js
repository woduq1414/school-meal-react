import React from 'react'
import axios from "axios";
let a = 3
const Sub1 = () => {
    return (
        <div>
        	POST SUB1
        </div>
    )
}

export default Sub1
