import React from 'react';

const Notfound = ({location}) => {
    return (
        <div>
            <p>"{location.pathname}" NOT FOUND</p>
        </div>
    );
};

export default Notfound;


