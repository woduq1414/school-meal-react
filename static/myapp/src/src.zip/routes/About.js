import React from 'react';
import SchoolCodeWrap from '../components/SchoolCodeWrap';

const About = () => {
    return (
        <div>
			ABOUT
            zaaaaaaaaa
            <SchoolCodeWrap/>
        </div>
    );
};

export default About;
