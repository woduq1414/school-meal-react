import React from 'react'
import { Redirect } from 'react-router-dom';

const Mypage = () => {
    return (
        <div>
			MY PAGE
        </div>
    );
};

export default Mypage;
