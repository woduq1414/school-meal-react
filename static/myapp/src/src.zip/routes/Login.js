import React from 'react'
import { Redirect } from 'react-router-dom';

const Login = () => {
    return (
        <div>
			LOGIN
        </div>
    );
};

export default Login;
